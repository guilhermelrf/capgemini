package game;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import javax.swing.text.Position;

import environment.LocalBoard;
import gui.SnakeGui;
import environment.Cell;
import environment.Board;
import environment.BoardPosition;

public class AutomaticSnake extends Snake {
	private BoardPosition snakePosition;
	private Cell currentCell;
	private boolean interruped;

	public AutomaticSnake(int id, LocalBoard board) {
		super(id, board);

	}

	private Cell moveToRandomCell(){
		Cell result = null;
		List<BoardPosition> possibleCells = getBoard().getNeighboringPositions(currentCell);
		possibleCells.removeIf(boardPosition -> getBoard().getCell(boardPosition).isOcupied());

		Random random = new Random();
        int randomIndex = random.nextInt(possibleCells.size());

		BoardPosition pos = possibleCells.get(randomIndex);
		result = getBoard().getCell(pos);
		return result;
	}

	private Cell moveToGoalCell() {
		Cell result = null;
		BoardPosition goalPosition = getBoard().getGoalPosition();
		double min_distanceToGoal = Double.MAX_VALUE;

		for (BoardPosition pos : getBoard().getNeighboringPositions(currentCell)) {
			Cell potencialCell = this.getBoard().getCell(pos);
			double distanceToGoal = pos.distanceTo(goalPosition);

			if (!this.cells.contains(potencialCell) && distanceToGoal < min_distanceToGoal) {
				result = potencialCell;
				min_distanceToGoal = distanceToGoal;
			}
		}

		return result;
	}

	@Override
	public void run() {
		doInitialPositioning();
		// System.err.println("initial size:"+cells.size());
		Cell nextCell = null;
		while (!getBoard().isFinished) {
			try {
				Thread.sleep(Board.PLAYER_PLAY_INTERVAL);
				snakePosition = getCells().getLast().getPosition();
				currentCell = getBoard().getCell(snakePosition);
				
				if(interruped){
					nextCell = moveToRandomCell();
					interruped = false;
				}
				else{
					nextCell = moveToGoalCell();
				}

				this.move(nextCell);

			} catch (Exception e) {
				interruped = true;
				System.out.println("snake " + this.getIdentification() + " interrupted");
				continue;
			}
		}
	}

}

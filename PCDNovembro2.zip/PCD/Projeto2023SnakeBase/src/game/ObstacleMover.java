package game;

import environment.BoardPosition;
import environment.LocalBoard;

public class ObstacleMover extends Thread {
	private Obstacle obstacle;
	private LocalBoard board;
	
	public ObstacleMover(Obstacle obstacle, LocalBoard board) {
		super();
		this.obstacle = obstacle;
		this.board = board;
	}

	@Override
	public void run() {
		while(obstacle.getRemainingMoves() > 0){
			try{
				//mover obstaculo movimento random
				obstacle.move();
				//obstacle.decrementRemaingMoves();
				//board.setChanged();
				Thread.sleep(Obstacle.OBSTACLE_MOVE_INTERVAL);
			}catch (Exception e){
				e.printStackTrace();
			}
		}
	}
}

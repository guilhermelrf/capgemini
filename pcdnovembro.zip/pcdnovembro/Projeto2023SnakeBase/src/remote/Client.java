package remote;


/** Remore client, only for part II
 * 
 * @author luismota
 *
 */

public class Client {

	public static void main(String[] args) {
	// TODO
	}

}

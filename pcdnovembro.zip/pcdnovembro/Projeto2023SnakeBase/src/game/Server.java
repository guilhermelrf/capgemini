package game;

public class Server {
	// TODO
}

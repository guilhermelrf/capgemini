public class Question_197 {

    public static void menu(){
        System.out.println("1. left 2. right 0. stop");
    }
    
    public static void main(String[] args) {
        int option;
        //insert code here
    }
}

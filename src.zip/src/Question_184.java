public class Question_184 {
    public static void main(String[] args) {
        int x;

        /* insert code here */

        /* Option A - Ok */

        x = 3;

        do {
            System.out.print("*");
            x--;
        } while (x >= 0);

        /* Option B - It does not enter the loop. */

        x = 0;
        do {
            System.out.print("*");
            x++;
        } while (x >= 3);

        /* Option C - It does not enter the loop. */

        x = 0;
        do {
            System.out.print("*");
            ++x;
        } while (x > 3);

        /* Option D - I only printed two asterisks */

        x = 3;
        do {
            System.out.print("*");
            x--;
        } while (x != 1);

        /* Option E - Ok */

        x = 0;
        do {
            System.out.print("*");
        } while (x++ < 3);

    }
}

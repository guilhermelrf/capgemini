public class Question_128 {
    abstract class Toy{
        int price;
        //line n1
    }

    public static void insertToy(){
        //code here
    }

    final Toy getToy(){
        return new Toy();
    }

    public void printToy();

    public int calculatePrice(){
        return price;
    }

    public abstract int computeDiscount();
}

public class Question_7 {

    class Vehicle {
        String type = "4W";
        int maxSpeed = 100;

        Vehicle(String type, int maxSpeed) {
            this.type = type;
            this.maxSpeed = maxSpeed;
        }

        Vehicle() {
        }
    }

    class Car extends Vehicle {
        String trans;

        Car(String trans) {
            this.trans = trans; // line n1
        }

        Car(String type, int maxspeed, String trans) {
            super(type, maxspeed); // line n2
            this.trans = trans;
        }
    }

    public static void main(String[] args) {
        Question_7 question = new Question_7();
        Question_7.Car c1 = question.new Car("Auto");
        Question_7.Car c2 = question.new Car("4W", 150, "Manual");
        System.out.println(c1.type + " " + c1.maxSpeed + " " + c1.trans);
        System.out.println(c2.type + " " + c2.maxSpeed + " " + c2.trans);
    }
}

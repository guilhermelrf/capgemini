package Question_224.root;

public class Tree {
	public void m1() {}
	private void m2() {}
	protected void m3() {}
	void m4() {};
}

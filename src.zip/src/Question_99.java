public class Question_99 {
    public static void main(String[] args) {
        System.out.println("Result A " + 0 + 1);
        System.out.println("Result B " + (1) + (2));
    }
}

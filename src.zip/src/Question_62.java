    A.java:

    public class A{
        public void a(){}
        int a;
    }

    B.java:

    public class B{
        private int doStuff(){
            private int x = 100;
            return x++;
        }
    }

    C.java:

    import java.io.*;
    package p1;
    class A{
        public static void main(String filename) throws IOException {
            
        }
    }

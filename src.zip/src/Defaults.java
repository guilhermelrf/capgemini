public class Defaults {
    byte byteVar;
    short shortVar;
    int intVar;
    long longVar;
    float floatVar;
    double doubleVar;
    char charVar;
    boolean booleanVar;

    public static void main(String[] args) {
        Defaults defaults = new Defaults();
        System.out.println("byteVar: " + defaults.byteVar);
        System.out.println("shortVar: " + defaults.shortVar);
        System.out.println("intVar: " + defaults.intVar);
        System.out.println("longVar: " + defaults.longVar);
        System.out.println("floatVar: " + defaults.floatVar);
        System.out.println("doubleVar: " + defaults.doubleVar);
        System.out.println("charVar: " + defaults.charVar);
        System.out.println("booleanVar: " + defaults.booleanVar);
    }
}

package passbyvalue;

public class PassByValueExample {
    public static void main(String[] args) {
        int num = 5;
        modifyPrimitive(num);
        System.out.println("Outside method: " + num);  // Output: 5
    }

    public static void modifyPrimitive(int value) {
        value = 10;  // Changes made inside the method do not affect the original value
    }
}


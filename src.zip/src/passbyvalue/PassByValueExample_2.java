package passbyvalue;

public class PassByValueExample_2 {
    public static void main(String[] args) {
        StringBuilder str = new StringBuilder("Hello");
        modifyReference(str);
        System.out.println("Outside method: " + str);  // Output: Hello World
    }

    public static void modifyReference(StringBuilder value) {
        value.append(" World");  // Changes made inside the method affect the original object
    }
}


package passbyvalue;

public class PassByValueExample_3 {
    public static void main(String[] args) {
        String str = "Hello";
        modifyReference(str);
        System.out.println("Outside method: " + str);  // Output: Hello
    }

    public static void modifyReference(String value) {
        value = value + " World";  // Changes made inside the method do not affect the original object
    }
}

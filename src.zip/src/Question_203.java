import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class Question_203 {
    public static void main(String[] args) {
	List<String> Ist = Arrays.asList("EN", "FR", "CH", "JP");
	Iterator<String> itr = Ist.iterator();
	while(itr.hasNext()) {
		String e = itr.next();
		if(e == "CH" ) {
			break;
		}
		System.out.println(e + " ");
	}
}
}

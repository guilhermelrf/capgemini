public class Question_55 {
    public static void main(String[] args) {
        int ivar = 100;
        float fvar = 100.00f;
        double dvar = 123;

        fvar = ivar;
        ivar = fvar;
        fvar = dvar;
        dvar = fvar;
        ivar = dvar;
        dvar = ivar;
    }
}

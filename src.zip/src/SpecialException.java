class SpecialException extends Exception {

    public SpecialException(String message) {
        super(message);
        System.out.println(message);
    }
}
import javax.swing.plaf.TreeUI;

public class Question_198 {
    public static void main(String[] args) {
        Boolean available = TRUE;
        String tmpAuthor = author, author = "Mc Donald";
        Double price = 200D;
        Integer pages = 20;

    }
}

public class Question_105 {
    public static void main(String[] args) {
        float flt = 100.00F;
        float flt2 = (float) 1_11.0;
        Float flt3 = 100.00;
        double y1 = 203.22; float flt4 = y1;
        int y2 = 100; float flt5 = (float) y2;
    }
}

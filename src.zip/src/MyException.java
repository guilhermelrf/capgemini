
public class MyException extends RuntimeException {
}

public class Question_183 {
    class Bird {
        public void fly() {
            System.out.print("Fly.");
        }
    }

    class Peacock extends Bird {
        public void dance() {
            System.out.print("Dance.");
        }
    }

    public static void main(String[] args) {
        Question_183 question = new Question_183();
        Bird b = question.new Peacock();
        Peacock p = (Peacock) b;

        p.fly();
        p.dance();
    }

}

package Question_202;

class S1 {
	protected void display(int x) {
		System.out.println("Parent" + x);
	}
}
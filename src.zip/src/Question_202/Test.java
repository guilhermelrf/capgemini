package Question_202;

public class Test {
    public static void main(String[] args) {
		
		S2 sobj = new S2();
		sobj.display(10, 100); // Child10  Child100    Parent100
	}
}

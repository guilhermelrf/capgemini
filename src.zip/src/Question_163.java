public class Question_163 {
    public static void main(String[] args) {
        int ii = 0;
        int jj = 7;
        for (ii = 0; ii < jj; ii = ii + 2) {
            System.out.print(ii + " ");
        }
    }
}

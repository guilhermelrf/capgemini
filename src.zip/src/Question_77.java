public class Question_77 {
public static void main(String[] args) {
    System.out.println("hello");
}

public static void main(String[] ) {
    System.out.println("hello");
}

public void main(String[] args) {
    System.out.println("hello");
}

public static void main(String() args) {
    System.out.println("hello");
}


}

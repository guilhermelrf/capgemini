public class Question_83 {
    public static void main(String[] args) {

        int aVar = 9;

        if (aVar++ < 10) {
            System.out.println(aVar + " Hello Universe!");
        } else {
            System.out.println(aVar + " Hello World!");
        }

    }
}

public class Question_76 {

    class Employee {
        public int salary;
    }
    
    class Manager extends Employee {
        public int budget;
    }
    
    public class Director extends Manager {
        public int stockOptions;
        
        public static void main (String [] args ) {
            Employee employee = new Employee();
            Manager manager = new Manager();
            Director director = new Director();
            
            employee.salary = 50_000; // A
            director.salary = 80_000; // B
        //	employee.budget = 200_000; // C
            manager.budget = 1_000_000; // D
        //	manager.stockOption = 500; // E
            director.stockOptions = 1_000; // F
            
            System.out.println(employee.salary);
            System.out.println(director.salary);
        //	System.out.println(stockOptions);
            System.out.println(manager.budget);
        //	System.out.println(manager.stockOption);
            System.out.println(director.stockOptions);
        }
    }
}

public static void main(String[] args) {
	int array[] = {10, 20, 30, 40, 50};
	int x = array.length;
	
	// Answer A - Ok
	/*
	while (x>0) {
		x--;
		System.out.println(array[x]);
	}
	*/
	
	// Answer B - ArrayIndexOutOfBoundsException // x = -1
	/*
	do {
		x--;
		System.out.print(array[x]);
	} while (x >= 0);
	*/
	
	// Answer C - ArrayIndexOutOfBoundsException // x = 5
	/*
	while (x >= 0) {
		System.out.print(array[x]);
		x--;
	}
	*/
	
	// Answer D - ArrayIndexOutOfBoundsException // x = 5
	/*
	do {
		System.out.print(array[x]);
		--x;
	} while (x > 0);
	*/
	
	// Answer E - Ok
	/*
	while(x > 0) {
		System.out.println(array[--x]);
	}
	*/
}
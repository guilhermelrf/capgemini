public class Question_42 {

    public static String maskCC(String creditCard) {
        String x = "XXXX-XXXX-XXXX-";
        // line n1
    }

    public static void main(String[] args) {
        System.out.println(maskCC("1234-5678-9101-1121"));
    }
} 

public class Question_41 {
    public static void main(String[] args) {
        String[] planetStrings = { "Mercury", "Venus", "Erath", "Mars" };
        System.out.println(planetStrings.length);
        System.out.println(planetStrings[1].length());
    }
}

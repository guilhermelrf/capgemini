
public class Question_187 {
    public static void main(String[] args) throws LogFileException {
        Question_187 obj = new Question_187();
        try {
            obj.open();
            obj.process();
                //insert code here
        } catch (Exception e) {
            System.out.println("Completed.");
        }
    }

    void process() throws LogFileException {
        System.out.println("Processed");
        throw new LogFileException();
    }

    void open() {
        System.out.println("Opened");
        throw new AccessViolationException();
    }
}

class LogFileException extends Exception {
}

class AccessViolationException extends RuntimeException {
}

public class Question_140 {
    public static void main(String[] args) {
        System.out.println("String main " + args[0]);		
    }
}

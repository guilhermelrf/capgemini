public class Question_81 {
int x;
	int y;
	
	public void doStuffy(int x, int y) {
		x = x;
		y = this.y;
	}
	
	public void display () {
		System.out.print(x + " " + y + " : ");
	}
	
	public static void main(String[] args) {		
		
		Question_81 m1 = new Question_81 ();
		m1.x = 100;
		m1.y = 200;
		Question_81 m2 = new Question_81();
		m2.doStuffy(m1.x, m1.y);
		m1.display();
		m2.display();

	}	
}

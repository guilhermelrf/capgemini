public class Question_49 {
    public static void main(String[] args) {
        String str = " ";
        str.trim();
        System.out.println(str.equals("") + " " + str.isEmpty());
    }
}

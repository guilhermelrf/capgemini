public class Question_67_2 {
    int num;

    public static void graceMarks(Question_67 obj4) {
        obj4.num += 10;
    }

    public int getNum(){
        return num;
    }

    public static void main(String[] args) {
        String obj1 = new String("obj1");
        String obj2 = obj1;
        System.out.println(obj1);
        obj2.replace('b', 'j');
        System.out.println(obj1);
        System.out.println(obj2);
        
        String obj3 = "obj3";
        String obj4 = obj3;
        System.out.println(obj3);
        obj3.replace('b', 'j');
        System.out.println(obj3);
        System.out.println(obj4);
    }
}

public class Main {
    public static void main(String[] args) {
        double result = divide(10, 3);
        System.out.println(result);
    }   

    public static double divide(int a, int b){
        double c = a;
        double d = b;
        return (c/d);
    }
}

import java.util.ArrayList;
import java.util.List;

public class Question_127 {
    public static void main(String[] args) {

        List <String> colors = new ArrayList();
        colors.add("Green");
        colors.add("Blue");
        colors.add("Red");
        colors.add("Yelow");
        colors.remove(2);
        colors.add(3,"Cyan");
        
        System.out.println(colors);
    }
}

public class Question_109 {
    public static void main(String[] args) {
        String myStr = "Hello World ";
        myStr.trim();
        int i1 = myStr.indexOf(" ");
        System.out.println(i1);
    }
}

public class Question_8 {

    class Caller {
        public void init() {
            System.out.println("Initialized");
        }

        public void start() {
            init();
            System.out.println("Started");
        }
    }

}
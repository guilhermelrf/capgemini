public class Question_102 {
    static int count = 0;
	int i = 0;
	
	public void changeCount() {
		while(i<5) {
			i++;
			count++;
		}
	}
	
	public static void main (String [] args) {
		Question_102 check1 = new Question_102 ();
		Question_102 check2 = new Question_102 ();
		check1.changeCount();
		check2.changeCount();
		System.out.print(check1.count + " : " + check2.count);
	}
}

public class Question_85 {
    public static void main(String[] args) {
        boolean a = new Boolean(Boolean.valueOf(args[0]));
        boolean b = new Boolean(args[1]);
        System.out.println(a + " " + b);
    }
}

public class Question_50 {
    public static void main(String[] args) {

        String str1 = "Java";
        String str2 = new String("java");

        //line n1 
            System.out.println("Equal");
        } else {
            System.out.println("Not Equal");
        }
    }
}

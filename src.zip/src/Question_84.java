public class Question_84 {
    public static void main (String[] args) {	
		String s = "Java SE 8 1";
		int len = s.trim().length();
		System.out.print(len);
	}
}

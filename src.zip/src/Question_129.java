public class Question_129 {
	int x, y;
	
	public Question_129 (int x, int y) {
		initialize(x, y);
	}
	
	public void initialize (int x, int y) {
		this.x = x * x;
		this.y = y * y;
	}
	
	public static void main (String [] args) {
		int x = 3, y = 5;
		Question_129 obj = new Question_129(x, y);
		System.out.println(x + " " + y);
	}
}
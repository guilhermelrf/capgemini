
    class Animal{
        String type = "Canine";
        int maxspeed = 60;
        Animal () {}

        Animal (String type, int maxspeed) {
            this.type = type;
            this.maxSpeed = maxSpeed;
        }

    }

    class WildAnimal extends Animal {
        String bounds;

        WildAnimal (String bounds) {
        //line n1
        }

        WildAnimal (String type, int maxSpeed, String bounds) {
        //line n2
        }
    }


    WildAnimal wolf = new WildAnimal ("Long") ;
    WildAnimal tiger = new WildAnimal ("Feline", 80, "Short");
    System.out.println(wolf.type + " " + wolf.maxSpeed + " " + wolf.bounds);
    System.out.println(tiger.type + " " + tiger.maxSpeed + " " + tiger.bounds);

super ();
this. bounds = bounds;

this.bounds = bounds;
super ();

super (type, maxSpeed);
this (bounds) ;

this ("Canine", 60);
this.bounds = bounds;

super (type, maxSpeed);
this.bounds = bounds;
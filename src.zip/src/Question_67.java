public class Question_67 {
    int num;

    public static void graceMarks(Question_67 obj4) {
        obj4.num += 10;
    }

    public static void main(String[] args) {
        Question_67 obj1 = new Question_67();
        Question_67 obj2 = obj1;
        Question_67 obj3 = null;
        obj2.num = 60;
        graceMarks(obj2);
    }
}

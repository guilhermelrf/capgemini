package Question_116;

public interface Exportable {
    void export();
}
package Question_116;

class Tool implements Exportable {
    void export() {
        System.out.println("Tool::export");
    }
}

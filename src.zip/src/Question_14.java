public class Question_14 {
    public static void main(String[] args) {
        int a[] = { 1, 2, 3, 4, 5 };
        for (int e = 0; e < 5; e += 2) {
            System.out.print(a[e]);
        }
    }
}

class Question_101 {
	String name;
	int age = 25;
	
	Question_101 (String name) { // line 1
		setName(name);
	}
	
	public Question_101 (String name, int age) {
		Question_101(name); // line 2
		setAge(age);
	}
	
	// setter and getter methods go here
	public void setName (String name) { this.name  = name; }
	public void setAge (int age) { this.age = age; }
	
	public String show() {
		return name + " " + age;
	}

	public static void main(String[] args) {
		Question_101 p1 = new Question_101("Jesse");
		Question_101 p2 = new Question_101("Walter",52);
		System.out.println(p1.show());
		System.out.println(p2.show());
	}
}
public class Question_212 {
    public static void main(String[] args) {
        int x;
        for (x = 100; x <= 100; x++) {
            System.out.println(x);
        }
    }
}

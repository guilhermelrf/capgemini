public class Question_159 {
    
}

abstract class Planet{
    protected void revolve(){
    }
    abstract void rotate();
}

class Earth extends Planet{
    private void revolve(){
    }
    private void rotate(){
    }
}
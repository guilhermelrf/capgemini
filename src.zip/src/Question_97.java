public class Question_97 {
    public static void main(String[] args) {
        int numbers[] = {12, 13, 42, 32, 15, 156, 23, 51, 12};
        int[] keys = findMax(numbers);
    }

    static int[] findMax(int[] max){
        int[] keys = new int[3];
        /*code goes here */
        return keys;
    }
}

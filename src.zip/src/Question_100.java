public class Question_100 {
    int count;
    public static void displayMessage() {
        count++;
        System.out.println("Welcome. Visit count: " + count);
        }
    public static void main(String[] args) {
        Question_100.displayMessage();
        Question_100.displayMessage();
    }
}

public class Question_161 {
    
}

public class App{
    int count;
    public static void displayMsg(){
        System.out.println("Welcome Visit Count: " + count++);
    }
    
    public static void main(String[] args) {
        App.displayMsg();
        displayMsg();
    }
}

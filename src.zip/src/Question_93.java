public class Question_93 {
    class Employee {
        private String name;
        private int age;
        private int salary;

        public Employee (String name, int age) {
            setName (name)
            setAge (age)
            setSalary (2000) ;
        }
        public Employee (String name, int age, int salary) {
            setSalary (salary);
            this (name, age);
        }

        //getter and setter methods for attributes go here

        public void printDetails () {
            System.out. println (name + " : " + age + " : " + salary);
        }
}

class Test {
    public static void main (String[] args) {
    Employee el = new Employee () ;
    Employee e2 = new Employee ("Jack", 50);
    Employee e3 = new Employee ("Chloe", 40,5000);
    el. printDetails () ;
    e2. printDetails () ;
    e3. printDetails () ;
}
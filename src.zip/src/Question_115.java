public class Question_115 {
    
}

public class CheckingAccount{
    public int amount;
    //line n1
}

public static void main(String[] args){
    CheckingAccount acct = new CheckingAccount();
    //line n2
}


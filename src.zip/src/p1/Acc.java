package p1;

public class Acc {
    int p = 0;
    private int q = 1;
    protected int r = 2;
    public int s = 3;
}

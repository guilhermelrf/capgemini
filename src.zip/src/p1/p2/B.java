package p1.p2;

import p1.*;

public class B {
    public static void main(String[] args) {
        A b = new A();
    }
}

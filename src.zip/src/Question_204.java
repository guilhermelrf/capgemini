public class Question_204 {
    class Vehicle {
        Vehicle(){
            System.out.println("Vehicle");
        }
    }
    
    class Bus extends Vehicle {
        Bus(){
            System.out.println("Bus");
        }
    }
    
    public class Test {
        public static void main(String[] args) {
            Vehicle v = new Bus();
        }
    }
}

public class Question_122 {
    public static void main(String[] args) {
        int wd = 0;
        String days[] = { "sun", "mon", "wed", "sat" };
        for (String s : days) {
            switch (s) {
                case "sat":
                    System.out.println("oi");
                case "sun":
                    wd--;
                    break;
                case "mon":
                    wd++;
                case "wed":
                    wd = wd + 2;
            }
        }
        System.out.print(wd + " ");
    }

    // public static void main(String[] args) {
    // int dayOfWeek = 2;

    // switch (dayOfWeek) {
    // case 1:
    // System.out.println("It's Monday!");
    // case 2:
    // System.out.println("It's Tuesday!");
    // case 3:
    // System.out.println("It's Wednesday!");
    // break;
    // case 4:
    // System.out.println("It's Thursday!");
    // break;
    // case 5:
    // System.out.println("It's Friday!");
    // break;
    // default:
    // System.out.println("It's the weekend!");
    // }
    // }
}
public class Question_13 {
    class CD {
        int r;
        CD(int r) {
            this.r = r;
        }
    }

    class DVD extends CD {
        int c;
        DVD(int r, int c) {
            super(r);
        }
    }

    public static void main(String[] args) {
        System.out.println("yo");
        Question_13 question = new Question_13();
        DVD dvd = question.new DVD(10, 20);

    }

}

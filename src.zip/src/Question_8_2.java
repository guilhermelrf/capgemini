public class Question_8_2 extends Question_8 {
    public static void main(String[] args) {
        Question_8 question = new Question_8();
        Question_8.Caller c = question.new Caller();
        c.start(); // line n1
        c.init(); // line n2
    }
}

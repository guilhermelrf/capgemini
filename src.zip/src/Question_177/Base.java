package Question_177;

class Base {
    public void test() {
        System.out.println("Base ");
    }
}

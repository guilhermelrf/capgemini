package Question_177;

class DerivedA extends Base {
    public void test() {
        System.out.println("DerivedA ");
    }
}